from PIL import Image, ImageDraw, ImageFont
import os.path
from os import path
from string import ascii_lowercase
from string import ascii_uppercase

numbers = ['0', '1', '2', '3', '4', '5', '6', '7', '8', '9']
symbols = {'_': 'underscore', '-': 'minus', '+': 'plus', '=': 'equals', '{': 'left_curly_bracket', '}': 'right_curly_bracket', '[': 'left_bracket', ']': 'right_bracket', '|': 'pipe', '\\': 'back_slash',
           ':': 'colon', ';': 'semicolon', '\'': 'single_quote', '"': 'double_quote', ',': 'comma', '<': 'less_than', '>': 'greater_than', '?': 'question_mark', '/': 'forward_slash', '`': 'accent', '~': 'tilde'}
fonts = ['arial', 'calibri', 'dialog', 'lucida sans', 'sanserif', 'sansserif', 'serif', 'times new roman', 'roman', 'lucidatypewriter', 'courier', 'helvetica', 'lucidabright', 'lucida', 'lucidav2']

# Font work below
# All saved images same height, to make the font smoother
# All saved images width of character + 1 to the right of each character. In SSDS each character at 12 sized font, has one pixel in between each other.

for font in fonts:
    if path.exists('C:/Windows/Fonts/' + font + '.ttf'):
        # Section ---
        used_fnt = ImageFont.truetype('C:/Windows/Fonts/' + font + '.ttf', 12)
        save_path = "C:/Users/JT/Documents/Light Eternal/Discord Bot/lighteternal-master/Codebase/Fonts/" + font.upper()
        character_height = 13
        if not path.exists(save_path):
            print("Creating path to save images for Font - " + font.upper())
            os.mkdir(save_path)

        # Section ---
        save_path = "C:/Users/JT/Documents/Light Eternal/Discord Bot/lighteternal-master/Codebase/Fonts/" + font.upper() + '/lower'
        if not path.exists(save_path):
            print("Creating path to save images for Font - " + font.upper())
            os.mkdir(save_path)
        for character in ascii_lowercase:
                text = str(character)
                character_width = used_fnt.getsize(text)[0] + 1
                img = Image.new('RGB', (character_width, character_height), color=(80, 80, 80))
                draw = ImageDraw.Draw(img)
                draw.text((0, 0), text, font=used_fnt, fill=(255, 255, 255))
                img.save(save_path + '/' + font.upper() + '_lower_' + text + '.png')

        # Section ---
        save_path = "C:/Users/JT/Documents/Light Eternal/Discord Bot/lighteternal-master/Codebase/Fonts/" + font.upper() + '/upper'
        if not path.exists(save_path):
            print("Creating path to save images for Font - " + font.upper())
            os.mkdir(save_path)
        for character in ascii_uppercase:
                text = str(character)
                character_width = used_fnt.getsize(text)[0] + 1
                img = Image.new('RGB', (character_width, character_height), color=(80, 80, 80))
                draw = ImageDraw.Draw(img)
                draw.text((0, 0), text, font=used_fnt, fill=(255, 255, 255))
                img.save(save_path + '/' + font.upper() + '_' + text + '.png')

        # Section ---
        save_path = "C:/Users/JT/Documents/Light Eternal/Discord Bot/lighteternal-master/Codebase/Fonts/" + font.upper() + '/number'
        if not path.exists(save_path):
            print("Creating path to save images for Font - " + font.upper())
            os.mkdir(save_path)
        for character in numbers:
                text = str(character)
                character_width = used_fnt.getsize(text)[0] + 1
                img = Image.new('RGB', (character_width, character_height), color=(80, 80, 80))
                draw = ImageDraw.Draw(img)
                draw.text((0, 0), text, font=used_fnt, fill=(255, 255, 255))
                img.save(save_path + '/' + font.upper() + '_' + text + '.png')

        # Section ---
        save_path = "C:/Users/JT/Documents/Light Eternal/Discord Bot/lighteternal-master/Codebase/Fonts/" + font.upper() + '/symbol'
        if not path.exists(save_path):
            print("Creating path to save images for Font - " + font.upper())
            os.mkdir(save_path)
        for character in symbols:
                text = str(character)
                character_width = used_fnt.getsize(text)[0] + 1
                img = Image.new('RGB', (character_width, character_height), color=(80, 80, 80))
                draw = ImageDraw.Draw(img)
                draw.text((0, 0), text, font=used_fnt, fill=(255, 255, 255))
                img.save(save_path + '/' + font.upper() + '_' + symbols[character] + '.png')
    else:
        print('\n' + font + ' - Respective font file does not exist, check spelling')
